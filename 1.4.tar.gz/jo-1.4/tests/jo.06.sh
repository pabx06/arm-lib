# strings and numbers; pretty (Vanessa)
${JO:-jo} -p artist="Vanessa Paradis" song="Joe le taxi" year=1987
