# array: true,false,null (native and string)
${JO:-jo} -a true false null '"true"' '"false"' '"null"'
