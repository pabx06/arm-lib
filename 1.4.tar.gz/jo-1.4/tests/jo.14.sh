# values: with equals signs in them
${JO:-jo} form==ok this===sure
