# basic logo
${JO:-jo} -a jo
