# data from file: base64-encoded
${JO:-jo} program="jo" authors=%${srcdir:=.}/AUTHORS
